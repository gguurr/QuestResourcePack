# QuestResourcePack

This is the Repository that houses the Resource pack that we use for the "Quest" Gamemode on SupremeObsidian.

### Downloading the Resourcepack

Clone the repository, into a directory on your computer, then (with git bash installed) run bake_resourcepack_zip.sh.

This will generate a **QuestResourcePack-main.zip** in the root directory of the project.