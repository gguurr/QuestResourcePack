- 'custom_model_data' tag can be from -2147483648 to 2147483647 ENG
- 'custom_model_data' тэг может быть от -2147483648 до 2147483647 RU

- 'damaged' tag can be from 0.00064 to 1 (0.00064 is 1/1561 durability) ENG
- 'damaged' тэг может быть от 0.00064 до 1 (0.00064 это 1/1561 прочности) RU
